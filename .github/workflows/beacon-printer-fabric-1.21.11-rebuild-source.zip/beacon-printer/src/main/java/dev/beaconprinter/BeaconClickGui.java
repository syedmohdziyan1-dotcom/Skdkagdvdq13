package dev.beaconprinter;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class BeaconClickGui extends Screen {
    private int panelX, panelY;
    private static final int PANEL_W = 240;
    private static final int PANEL_H = 150;

    public BeaconClickGui() { super(Text.literal("Beacon Printer")); }

    @Override
    protected void init() {
        panelX = (width - PANEL_W) / 2;
        panelY = (height - PANEL_H) / 2;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, 0xEE101923);
        context.fill(panelX, panelY, panelX + PANEL_W, panelY + 24, 0xFF1D4961);
        context.drawText(textRenderer, "Beacon Printer", panelX + 10, panelY + 8, 0xFFFFFFFF, false);
        context.drawText(textRenderer, "Auto Fingerprinter", panelX + 12, panelY + 40, 0xFFFFFFFF, false);
        String status = MacroController.isRecording() ? "RECORDING" :
                MacroController.isReplaying() ? "REPLAYING" : "OFF";
        context.drawText(textRenderer, "Status: " + status, panelX + 12, panelY + 58, 0xFFB7D9E8, false);
        context.drawText(textRenderer, "Recorded actions: " + MacroController.actionCount(),
                panelX + 12, panelY + 75, 0xFFB7D9E8, false);
        context.fill(panelX + 12, panelY + 100, panelX + 112, panelY + 124, 0xFF285A43);
        context.drawText(textRenderer, "Enable / Stop", panelX + 20, panelY + 108, 0xFFFFFFFF, false);
        context.fill(panelX + 122, panelY + 100, panelX + 222, panelY + 124, 0xFF713B3B);
        context.drawText(textRenderer, "Delete last", panelX + 137, panelY + 108, 0xFFFFFFFF, false);
        context.drawText(textRenderer, "Right-click module settings: delete last action",
                panelX + 12, panelY + 134, 0xFF9AAAB4, false);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean insideModule = mouseX >= panelX + 8 && mouseX <= panelX + 230
                && mouseY >= panelY + 32 && mouseY <= panelY + 92;
        if (insideModule && button == 1) {
            MacroController.deleteLast();
            return true;
        }
        if (mouseX >= panelX + 12 && mouseX <= panelX + 112
                && mouseY >= panelY + 100 && mouseY <= panelY + 124 && button == 0) {
            if (MacroController.isReplaying()) MacroController.stopReplay(client);
            else MacroController.startReplay(client);
            return true;
        }
        if (mouseX >= panelX + 122 && mouseX <= panelX + 222
                && mouseY >= panelY + 100 && mouseY <= panelY + 124 && button == 0) {
            MacroController.deleteLast();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() { return false; }
}
