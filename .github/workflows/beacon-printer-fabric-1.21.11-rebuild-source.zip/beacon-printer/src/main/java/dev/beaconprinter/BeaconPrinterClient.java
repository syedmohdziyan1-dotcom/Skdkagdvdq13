package dev.beaconprinter;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class BeaconPrinterClient implements ClientModInitializer {
    public static final String MOD_ID = "beaconprinter";
    public static KeyMapping clickGuiKey;
    public static KeyMapping recordKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.of(MOD_ID, "main"));
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.beaconprinter.clickgui", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        recordKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.beaconprinter.record", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_H, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (clickGuiKey.consumeClick()) {
                if (client.currentScreen instanceof BeaconClickGui) client.setScreen(null);
                else client.setScreen(new BeaconClickGui());
            }
            while (recordKey.consumeClick()) {
                MacroController.toggle(client);
            }
            MacroController.tick(client);
        });
    }
}
