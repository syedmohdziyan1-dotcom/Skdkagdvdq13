package dev.beaconprinter.mixin;

import dev.beaconprinter.MacroController;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClickSlotMixin {
    @Shadow private int lastSelectedSlot;

    @Inject(method = "clickSlot", at = @At("HEAD"))
    private void beaconprinter$recordSlotClick(int syncId, int slotId, int button,
                                               SlotActionType actionType,
                                               net.minecraft.entity.player.Player player,
                                               CallbackInfo ci) {
        MacroController.recordSlotClick(syncId,
                player.currentScreenHandler.getRevision(), slotId, button, actionType);
    }
}
