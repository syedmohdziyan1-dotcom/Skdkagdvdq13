package dev.beaconprinter;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Records generic container slot actions. This is intentionally limited to
 * inventory/container actions and chat commands; it does not capture passwords,
 * arbitrary text fields, or raw desktop input.
 */
public final class MacroController {
    public sealed interface Action permits SlotClick, ChatCommand {
        long delayMs();
    }
    public record SlotClick(long delayMs, int syncId, int revision, int slot,
                            int button, SlotActionType actionType) implements Action {}
    public record ChatCommand(long delayMs, String command) implements Action {}

    private static final List<Action> actions = new ArrayList<>();
    private static boolean recording;
    private static boolean replaying;
    private static int replayIndex;
    private static long lastActionAt;
    private static long nextReplayAt;

    private MacroController() {}

    public static boolean isRecording() { return recording; }
    public static boolean isReplaying() { return replaying; }
    public static int actionCount() { return actions.size(); }

    public static void toggle(MinecraftClient client) {
        if (recording) {
            recording = false;
            message(client, "Recording stopped. " + actions.size() + " actions saved.");
        } else if (replaying) {
            replaying = false;
            message(client, "Replay stopped.");
        } else {
            actions.clear();
            recording = true;
            replaying = false;
            lastActionAt = System.currentTimeMillis();
            message(client, "Recording started. Press H to finish.");
        }
    }

    public static void recordSlotClick(int syncId, int revision, int slot,
                                       int button, SlotActionType type) {
        if (!recording) return;
        long now = System.currentTimeMillis();
        actions.add(new SlotClick(Math.max(0, now - lastActionAt), syncId,
                revision, slot, button, type));
        lastActionAt = now;
    }

    public static void recordCommand(String command) {
        if (!recording || command == null || command.isBlank()) return;
        long now = System.currentTimeMillis();
        actions.add(new ChatCommand(Math.max(0, now - lastActionAt), command));
        lastActionAt = now;
    }

    public static void startReplay(MinecraftClient client) {
        if (actions.isEmpty()) {
            message(client, "Nothing recorded yet.");
            return;
        }
        recording = false;
        replaying = true;
        replayIndex = 0;
        nextReplayAt = System.currentTimeMillis() + actions.get(0).delayMs();
        message(client, "Auto Fingerprinter enabled. Press H to stop.");
    }

    public static void stopReplay(MinecraftClient client) {
        replaying = false;
        message(client, "Auto Fingerprinter stopped.");
    }

    public static void deleteLast() {
        if (!actions.isEmpty()) actions.remove(actions.size() - 1);
    }

    public static void clear() {
        actions.clear();
        recording = false;
        replaying = false;
    }

    public static void tick(MinecraftClient client) {
        if (!replaying || client.player == null || client.getNetworkHandler() == null) return;
        long now = System.currentTimeMillis();
        if (now < nextReplayAt) return;
        if (replayIndex >= actions.size()) {
            replayIndex = 0;
            nextReplayAt = now + (actions.isEmpty() ? 0 : actions.get(0).delayMs());
            return;
        }
        Action action = actions.get(replayIndex++);
        try {
            if (action instanceof SlotClick click) {
                if (client.player.currentScreenHandler.syncId == click.syncId()
                        && client.currentScreen instanceof HandledScreen<?>) {
                    client.interactionManager.clickSlot(click.syncId(), click.slot(),
                            click.button(), click.actionType(), client.player);
                }
            } else if (action instanceof ChatCommand command) {
                String value = command.command();
                if (value.startsWith("/")) value = value.substring(1);
                client.getNetworkHandler().sendChatCommand(value);
            }
        } catch (RuntimeException ex) {
            stopReplay(client);
            message(client, "Replay stopped after an interaction error.");
            return;
        }
        long delay = replayIndex < actions.size() ? actions.get(replayIndex).delayMs() : 250;
        nextReplayAt = now + Math.max(35, delay);
    }

    private static void message(MinecraftClient client, String text) {
        if (client.player != null) client.player.sendMessage(Text.literal("[Beacon Printer] " + text), false);
    }
}
