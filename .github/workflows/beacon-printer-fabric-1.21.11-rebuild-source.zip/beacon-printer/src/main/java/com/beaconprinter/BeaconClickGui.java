package com.beaconprinter;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class BeaconClickGui extends Screen {
    private boolean settingsOpen = false;
    private int moduleX, moduleY;
    public BeaconClickGui(){ super(Text.literal("Beacon Printer")); }
    @Override protected void init(){
        int cx=width/2, y=height/2-42;
        moduleX=cx-105; moduleY=y;
        clearChildren();
        addDrawableChild(ButtonWidget.builder(Text.literal("Auto Fingerprinter: "+(MacroController.enabled()?"ON":"OFF")), b->{MacroController.setEnabled(!MacroController.enabled()); clearAndInit();}).dimensions(moduleX,moduleY,210,20).build());
        if(settingsOpen){
            addDrawableChild(ButtonWidget.builder(Text.literal("Delete last recorded action ("+MacroController.count()+")"),b->{MacroController.deleteLast();clearAndInit();}).dimensions(cx-105,y+28,210,20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Start loop playback"),b->MacroController.startPlayback()).dimensions(cx-105,y+54,210,20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Back"),b->{settingsOpen=false;clearAndInit();}).dimensions(cx-105,y+80,210,20).build());
        } else {
            addDrawableChild(ButtonWidget.builder(Text.literal("Close"),b->close()).dimensions(cx-105,y+28,210,20).build());
        }
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button){
        if(button==1 && mouseX>=moduleX && mouseX<=moduleX+210 && mouseY>=moduleY && mouseY<=moduleY+20){settingsOpen=true;clearAndInit();return true;}
        return super.mouseClicked(mouseX,mouseY,button);
    }
    @Override public void render(DrawContext context,int mouseX,int mouseY,float delta){
        renderBackground(context,mouseX,mouseY,delta);
        context.drawCenteredTextWithShadow(textRenderer,title,width/2,height/2-75,0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,Text.literal("H: record / stop  •  Right-click module: settings"),width/2,height/2+75,0xAAAAAA);
        context.drawCenteredTextWithShadow(textRenderer,Text.literal("Mode: "+MacroController.mode()+"  |  Actions: "+MacroController.count()),width/2,height/2+89,0xAAAAAA);
        super.render(context,mouseX,mouseY,delta);
    }
    @Override public boolean shouldPause(){return false;}
}
