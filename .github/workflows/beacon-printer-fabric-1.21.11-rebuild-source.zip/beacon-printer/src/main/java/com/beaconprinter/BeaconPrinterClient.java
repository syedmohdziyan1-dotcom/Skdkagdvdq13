package com.beaconprinter;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class BeaconPrinterClient implements ClientModInitializer {
    private static KeyBinding toggleGui, recordKey;
    @Override public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("beaconprinter", "controls"));
        toggleGui = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.beaconprinter.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        recordKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.beaconprinter.record", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, category));
        MacroController.load();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleGui.wasPressed()) client.setScreen(new BeaconClickGui());
            while (recordKey.wasPressed()) MacroController.toggleRecordOrStop();
            MacroController.captureMovement(client);
            MacroController.tick(client);
        });
    }
}
