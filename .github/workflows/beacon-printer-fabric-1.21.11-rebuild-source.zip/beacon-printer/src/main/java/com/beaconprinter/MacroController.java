package com.beaconprinter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.client.MinecraftClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class MacroController {
    public enum Mode { IDLE, RECORDING, PLAYING }
    public static final class Action {
        String type; int delay; int a,b,c; String value;
        Action(String type,int delay,int a,int b,int c,String value){this.type=type;this.delay=delay;this.a=a;this.b=b;this.c=c;this.value=value;}
    }
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("beacon-printer-macro.json");
    private static final List<Action> ACTIONS = new ArrayList<>();
    private static Mode mode = Mode.IDLE;
    private static long lastRecordTick;
    private static int cursor, waitTicks;
    private static boolean enabled = true;
    private MacroController() {}

    public static Mode mode(){return mode;}
    public static int count(){return ACTIONS.size();}
    public static boolean enabled(){return enabled;}
    public static void setEnabled(boolean value){enabled=value; if(!value) stopPlayback();}

    public static void toggleRecordOrStop() {
        if (!enabled) return;
        if (mode == Mode.RECORDING) { mode=Mode.IDLE; save(); notify("Recording saved: " + ACTIONS.size() + " actions"); }
        else if (mode == Mode.PLAYING) stopPlayback();
        else { ACTIONS.clear(); mode=Mode.RECORDING; lastRecordTick=0; notify("Recording started"); }
    }
    public static void startPlayback() {
        if (!enabled || ACTIONS.isEmpty()) { notify("Nothing recorded"); return; }
        if (mode == Mode.RECORDING) { mode=Mode.IDLE; save(); }
        mode=Mode.PLAYING; cursor=0; waitTicks=0; notify("Loop playback started");
    }
    public static void stopPlayback(){ mode=Mode.IDLE; releaseMovement(); notify("Playback stopped"); }
    public static void deleteLast(){ if(!ACTIONS.isEmpty()){ACTIONS.remove(ACTIONS.size()-1); save();} }

    public static void recordSlot(int syncId,int slot,int button,SlotActionType type){
        if(mode!=Mode.RECORDING) return;
        add(new Action("slot", elapsed(), syncId, slot, button, type.name()));
    }
    public static void recordChat(String message){
        if(mode==Mode.RECORDING) add(new Action("chat", elapsed(),0,0,0,message));
    }
    private static int elapsed(){long now=System.currentTimeMillis(); int d=lastRecordTick==0?0:(int)Math.min(1200,(now-lastRecordTick)/50); lastRecordTick=now; return d;}
    private static void add(Action a){ACTIONS.add(a); if(ACTIONS.size()>5000) ACTIONS.remove(0);}

    public static void tick(MinecraftClient client){
        if(mode!=Mode.PLAYING || client.player==null || client.world==null) return;
        if(waitTicks>0){waitTicks--;return;}
        Action a=ACTIONS.get(cursor);
        execute(client,a);
        waitTicks=Math.max(0,a.delay);
        cursor++;
        if(cursor>=ACTIONS.size()) cursor=0;
    }
    private static void execute(MinecraftClient client,Action a){
        try {
            switch(a.type){
                case "slot" -> {
                    if(client.player.currentScreenHandler.syncId==a.a && client.interactionManager!=null)
                        client.interactionManager.clickSlot(a.a,a.b,a.c,SlotActionType.valueOf(a.value),client.player);
                }
                case "chat" -> {
                    if(client.player.networkHandler!=null){
                        if(a.value.startsWith("/")) client.player.networkHandler.sendChatCommand(a.value.substring(1));
                        else client.player.networkHandler.sendChatMessage(a.value);
                    }
                }
                case "keys" -> applyKeys(client.player,a.value);
            }
        } catch(Exception ignored) { /* A menu may have changed since recording; skip unsafe action. */ }
    }
    private static void applyKeys(ClientPlayerEntity p,String bits){
        KeyBinding[] keys={MinecraftClient.getInstance().options.forwardKey,MinecraftClient.getInstance().options.backKey,MinecraftClient.getInstance().options.leftKey,MinecraftClient.getInstance().options.rightKey,MinecraftClient.getInstance().options.jumpKey,MinecraftClient.getInstance().options.sprintKey};
        for(int i=0;i<keys.length;i++) keys[i].setPressed(i<bits.length() && bits.charAt(i)=='1');
    }
    public static void captureMovement(MinecraftClient client){
        if(mode!=Mode.RECORDING || client.player==null) return;
        var o=client.options;
        String bits=(o.forwardKey.isPressed()?"1":"0")+(o.backKey.isPressed()?"1":"0")+(o.leftKey.isPressed()?"1":"0")+(o.rightKey.isPressed()?"1":"0")+(o.jumpKey.isPressed()?"1":"0")+(o.sprintKey.isPressed()?"1":"0");
        if(ACTIONS.isEmpty() || !"keys".equals(ACTIONS.get(ACTIONS.size()-1).type) || !bits.equals(ACTIONS.get(ACTIONS.size()-1).value)) add(new Action("keys",elapsed(),0,0,0,bits));
    }
    private static void releaseMovement(){
        MinecraftClient c=MinecraftClient.getInstance();
        c.options.forwardKey.setPressed(false);c.options.backKey.setPressed(false);c.options.leftKey.setPressed(false);c.options.rightKey.setPressed(false);c.options.jumpKey.setPressed(false);c.options.sprintKey.setPressed(false);
    }
    public static void load(){try{Files.createDirectories(FILE.getParent());if(Files.exists(FILE)){Type t=new TypeToken<List<Action>>(){}.getType();List<Action> loaded=GSON.fromJson(Files.readString(FILE),t);if(loaded!=null)ACTIONS.addAll(loaded);}}catch(Exception ignored){}}
    private static void save(){try{Files.createDirectories(FILE.getParent());Files.writeString(FILE,GSON.toJson(ACTIONS));}catch(IOException e){notify("Could not save macro");}}
    private static void notify(String s){MinecraftClient c=MinecraftClient.getInstance();if(c.player!=null)c.player.sendMessage(Text.literal("[Beacon Printer] "+s),false);}
}
