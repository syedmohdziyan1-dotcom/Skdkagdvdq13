# Beacon Printer — Fabric 1.21.11

Client-side macro recorder/replayer source project. This rebuild uses one mapping namespace (Yarn `1.21.11+build.3`) throughout. It is **source code, not a precompiled JAR**.

## Controls

- **Right Shift** — open Beacon Printer ClickGUI.
- **H** — start recording; press again to stop and save. While playback is running, H stops it.
- **Left-click Auto Fingerprinter** — enable/disable the module.
- **Right-click Auto Fingerprinter** — open its settings.
- **Start loop playback** — repeat the saved action sequence until stopped.
- **Delete last recorded action** — remove the final action from the current macro.

## What this build records

- Movement key state changes for forward/back/left/right/jump/sprint.
- Standard Minecraft container slot actions (slot, mouse button, action type and timing), through `ClientPlayerInteractionManager.clickSlot`.
- Chat messages and slash commands submitted from the normal chat screen.

Recordings are saved at `config/beacon-printer-macro.json` in the Minecraft game directory.

## Important limitations

- This is **not yet a verified compiled release**. The build environment used to prepare this archive did not have Gradle or network/DNS access, so I could not run `gradle build` or launch Minecraft. Do not treat this ZIP as a tested JAR.
- Slot replay is guarded by the recorded container `syncId`. If a server opens a different container/session or changes its menu layout, that click is skipped rather than blindly sent. Many plugin menus built from ordinary inventory containers work through this path; custom client-side screens, coordinate-only buttons, drag gestures, text fields inside custom screens, and menus that change IDs/layout dynamically are not fully supported.
- Movement is represented as key-state changes, not exact mouse-look/camera movement, block target selection, attack-hold, item-use-hold, scroll wheel, or every possible mouse input.
- Chat capture records the submitted text, not individual keystrokes while typing. Sensitive commands/passwords typed into chat may be stored in the local macro JSON. Do not record secrets.
- Macros can trigger repeated server actions. Use only where the server permits automation; some servers prohibit macros.

## Build

Requires JDK 21 and Gradle 9.2.1 (the configured Loom 1.14.10 release requires Gradle 9.2).

```bash
gradle build
```

The remapped mod JAR should be produced under `build/libs/` if the dependency versions resolve and compilation succeeds. Install the resulting JAR in the `mods` folder of a Fabric 1.21.11 client with Fabric API installed.

## Compatibility configuration

- Minecraft: `1.21.11`
- Yarn: `1.21.11+build.3`
- Fabric Loader: `0.18.1` minimum
- Fabric API: `0.141.6+1.21.11`
- Java: 21
